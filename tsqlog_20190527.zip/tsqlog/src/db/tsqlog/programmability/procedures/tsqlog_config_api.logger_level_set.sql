set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create empty procedure
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config_api].[logger_level_set]'), 'IsProcedure') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating empty procedure [tsqlog_config_api].[logger_level_set]...'
	---
	exec sp_executesql N'create procedure [tsqlog_config_api].[logger_level_set] as begin print ''empty procedure [tsqlog_config_api].[logger_level_set]''; end'
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created empty procedure [tsqlog_config_api].[logger_level_set].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists empty procedure [tsqlog_config_api].[logger_level_set].'
go

---
--- alter procedure
---
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altering procedure [tsqlog_config_api].[logger_level_set]...'
go
---
alter procedure [tsqlog_config_api].[logger_level_set]
(
	@level_name varchar(100)
,	@level_int int
,	@out_message nvarchar(max) 
)
as 
begin
	set nocount on
	
	update	ll
	set		ll.level_int = @level_int
	from	tsqlog_config.logger_level ll
	where	ll.level_name = @level_name;
	
	if @@rowcount = 0
	begin
		set @out_message = 'level not exists!'
		return -1 
	end

	return 0
end
go
--
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altered procedure [tsqlog_config_api].[logger_level_set]...'
go