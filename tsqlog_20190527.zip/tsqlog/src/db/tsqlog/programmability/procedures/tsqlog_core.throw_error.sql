set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create empty procedure
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_core].[throw_error]'), 'IsProcedure') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating empty procedure [tsqlog_core].[throw_error]...'
	---
	exec sp_executesql N'create procedure [tsqlog_core].[throw_error] as begin print ''empty procedure [tsqlog_core].[throw_error]''; end'
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created empty procedure [tsqlog_core].[throw_error].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists empty procedure [tsqlog_core].[throw_error].'
go

---
--- alter procedure
---
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altering procedure [tsqlog_core].[throw_error]...'
go
---
alter procedure [tsqlog_core].[throw_error]
(
	@message nvarchar(max) 
,	@caller_procid int = null
)
as 
begin
	set nocount on
	set xact_abort on

	declare @procedure_name varchar(128) = object_name(@caller_procid)

	-- format message
	select @message = formatmessage('%s%s', isnull('caller:' + @procedure_name + ' - ',''), isnull(@message,''));
	
	-- throw error
	raiserror(@message, 16, 1);
	
	return 0
end
go
--
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altered procedure [tsqlog_core].[throw_error]...'
go

