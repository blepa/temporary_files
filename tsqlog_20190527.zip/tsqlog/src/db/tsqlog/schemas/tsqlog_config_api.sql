set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

if not exists ( select 1 from sys.schemas s where s.name = 'tsqlog_config_api')
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating schema [tsqlog_config_api]...'
	---
	exec sp_executesql N'create schema [tsqlog_config_api]'
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created schema [tsqlog_config_api].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists schema [tsqlog_config_api].'
go

set nocount off
go