set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create temp table
---
if object_id('tempdb..#tmp_tsqlog_config_logger_level') is not null drop table #tmp_tsqlog_config_logger_level
go

select top(0) level_name, level_int into #tmp_tsqlog_config_logger_level from [tsqlog_config].[logger_level]
go

---
--- add data to temp table
---
insert into #tmp_tsqlog_config_logger_level(level_name,level_int)
select 'OFF',0
union all
select 'FATAL',100
union all
select 'ERROR',200
union all
select 'WARN', 300
union all
select 'INFO', 400
union all
select 'DEBUG', 500
union all
select 'TRACE', 600
union all
select 'ALL', 214748364
go

---
--- add data to target table
---
declare @row_insert int = 0

-- get row number to insert
select @row_insert = count(1) from #tmp_tsqlog_config_logger_level

-- add new records
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Adding new records into table [tsqlog_config].[logger_level]...'
insert into [tsqlog_config].[logger_level](level_name,level_int)
---
select  tmp.level_name, tmp.level_int
from	#tmp_tsqlog_config_logger_level tmp
left 
join	[tsqlog_config].[logger_level] t on tmp.level_name = t.level_name
where	t.level_name is null
---
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Added ' + cast(@@rowcount as varchar(max)) + ' new records into table [tsqlog_config].[logger_level].'

print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Updating level_int into table [tsqlog_config].[logger_level]...'
---
update	t
set		t.level_int = tmp.level_int
from	[tsqlog_config].[logger_level] t
		join #tmp_tsqlog_config_logger_level tmp on t.level_name = tmp.level_name
where	t.level_int != tmp.level_int
---
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Updated level_int ' + cast(@@rowcount as varchar(max)) + ' new records into table [tsqlog_config].[logger_level].'
go