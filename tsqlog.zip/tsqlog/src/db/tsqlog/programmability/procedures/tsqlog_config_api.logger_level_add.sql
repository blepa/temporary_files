set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create empty procedure
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config_api].[logger_level_add]'), 'IsProcedure') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating empty procedure [tsqlog_config_api].[logger_level_add]...'
	---
	exec sp_executesql N'create procedure [tsqlog_config_api].[logger_level_add] as begin print ''empty procedure [tsqlog_config_api].[logger_level_add]''; end'
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created empty procedure [tsqlog_config_api].[logger_level_add].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists empty procedure [tsqlog_config_api].[logger_level_add].'
go

---
--- alter procedure
---
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altering procedure [tsqlog_config_api].[logger_level_add]...'
go
---
alter procedure [tsqlog_config_api].[logger_level_add]
(
	@level_name varchar(10)
,	@level_int int
,	@out_message nvarchar(max) 
)
as 
begin
	set nocount on
	
	insert into tsqlog_config.logger_level(level_name, level_int)
	select @level_name, @level_int
	where  not exists (select 1 from tsqlog_config.logger_level where level_name = @level_name);
	
	if @@rowcount = 0
	begin
		set @out_message = 'level exists!'
		return -1
	end

	return 0
end
go
--
print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Altered procedure [tsqlog_config_api].[logger_level_add]...'
go