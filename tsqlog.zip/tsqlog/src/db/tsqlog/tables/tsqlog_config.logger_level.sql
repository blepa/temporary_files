set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create table 
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[logger_level]'), 'IsUserTable') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating table [tsqlog_config].[logger_level]...'
	---
	create table [tsqlog_config].[logger_level]
	(
		[level_name] varchar(100) not null
	,	[level_int] int not null
	,	[create_date] datetime not null
	,	[create_user] varchar(100) not null
	,	[modify_date] datetime null
	,	[modify_user] varchar(100) null
	,	[row_ver] rowversion not null
	)
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created table [tsqlog_config].[logger_level].'
end
else
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists table [tsqlog_config].[logger_level].'
go

---
--- create primary key
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[pk_logger_level]'), 'IsPrimaryKey') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating primary key [tsqlog_config].[pk_logger_level]...'
	---
	alter table [tsqlog_config].[logger_level]
		add constraint [pk_logger_level]
		primary key clustered (level_name)
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created primary key [tsqlog_config].[pk_logger_level].'
end
else
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists primary key [tsqlog_config].[pk_logger_level].'
go

---
--- create default
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[df_logger_level_create_date]'), 'IsDefaultCnst') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating default constraint [tsqlog_config].[df_logger_level_create_date]...'
	---
	alter table [tsqlog_config].[logger_level]
		add constraint [df_logger_level_create_date]
		default (getdate())
		for [create_date]
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created default constraint [tsqlog_config].[df_logger_level_create_date].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists default constraint [tsqlog_config].[df_logger_level_create_date].'
go

---
--- create default
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[df_logger_level_create_user]'), 'IsDefaultCnst') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating default constraint [tsqlog_config].[df_logger_level_create_user]...'
	---
	alter table [tsqlog_config].[logger_level]
		add constraint [df_logger_level_create_user]
		default (suser_sname())
		for [create_user]
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created default constraint [tsqlog_config].[df_logger_level_create_user].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists default constraint [tsqlog_config].[df_logger_level_create_user].'
go