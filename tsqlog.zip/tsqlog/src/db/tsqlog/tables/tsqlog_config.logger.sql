set nocount on
go 
set ansi_nulls on
go
set quoted_identifier on
go

---
--- create table 
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[logger]'), 'IsUserTable') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating table [tsqlog_config].[logger]...'
	---
	create table [tsqlog_config].[logger]
	(
		[logger_name] varchar(255) not null
	,	[level_name] varchar(100) not null
	,	[level_int] int not null	
	,	[create_date] datetime not null
	,	[create_user] varchar(100) not null
	,	[modify_date] datetime null
	,	[modify_user] varchar(100) null
	,	[row_ver] rowversion not null
	)
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created table [tsqlog_config].[logger].'
end
else
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists table [tsqlog_config].[logger].'
go

---
--- create primary key
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[pk_logger]'), 'IsPrimaryKey') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating primary key [tsqlog_config].[pk_logger]...'
	---
	alter table [tsqlog_config].[logger]
		add constraint [pk_logger]
		primary key clustered (logger_name)
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created primary key [tsqlog_config].[pk_logger].'
end
else
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists primary key [tsqlog_config].[pk_logger].'
go

---
--- create foreign key
--- 
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[fk_logger_logger_level]'), 'IsForeignKey') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating foreign key [tsqlog_config].[fk_logger_logger_level]...'
	---
	alter table [tsqlog_config].[logger]
		add constraint fk_logger_logger_level
		foreign key ([level_name])
		references [tsqlog_config].[logger_level]([level_name])
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created foreign key [tsqlog_config].[fk_logger_logger_level].'
end
else
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists foreign key [tsqlog_config].[fk_logger_logger_level].'
go

---
--- create default
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[df_logger_create_date]'), 'IsDefaultCnst') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating default constraint [tsqlog_config].[df_logger_create_date]...'
	---
	alter table [tsqlog_config].[logger]
		add constraint [df_logger_create_date]
		default (getdate())
		for [create_date]
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created default constraint [tsqlog_config].[df_logger_create_date].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists default constraint [tsqlog_config].[df_logger_create_date].'
go

---
--- create default
---
if not exists (select 1 where objectproperty(object_id('[tsqlog_config].[df_logger_create_user]'), 'IsDefaultCnst') = 1)
begin
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Creating default constraint [tsqlog_config].[df_logger_create_user]...'
	---
	alter table [tsqlog_config].[logger]
		add constraint [df_logger_create_user]
		default (suser_sname())
		for [create_user]
	---
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Created default constraint [tsqlog_config].[df_logger_create_user].'
end
else 
	print convert(varchar(23),getdate(),121) + ' ' + @@servername + '.' + db_name() + ' - Exists default constraint [tsqlog_config].[df_logger_create_user].'
go